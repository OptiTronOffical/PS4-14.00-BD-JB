package org.bdj;

import java.io.IOException;

final class LocalResultLedger {
   private final OfflineRenderer.ScheduleEntry[] schedule;
   private final OfflineRenderer.Rule[] rules;
   private final OfflineRenderer.Shape[] shapes;
   private final OfflineRenderer.Guards guards;
   private final OfflineRenderer.TemplatePin[] pins;
   private final OfflineRenderer.MarkerPlan markerPlan;
   private final int[] markerWords;
   private final OfflineRenderer.WriteSite[] writeSites;
   private final OfflineRenderer.Frame[] frames = new OfflineRenderer.Frame[48];
   private int at;
   private boolean awaitingResult;
   private boolean failed;
   private boolean successWindowConfirmed;
   private int pendingInstructionCount;

   LocalResultLedger(OfflineRenderer.ScheduleEntry[] var1, OfflineRenderer.Rule[] var2, OfflineRenderer.Shape[] var3, OfflineRenderer.Guards var4, OfflineRenderer.TemplatePin[] var5, OfflineRenderer.MarkerPlan var6, int[] var7, OfflineRenderer.WriteSite[] var8) {
      this.schedule = var1;
      this.rules = var2;
      this.shapes = var3;
      this.guards = var4;
      this.pins = var5;
      this.markerPlan = var6;
      this.markerWords = (int[])var7.clone();
      this.writeSites = var8;
   }

   int currentCommand() throws IOException {
      if (!this.failed && this.at < this.schedule.length) {
         return this.schedule[this.at].command;
      } else {
         throw new IOException("ledger stopped");
      }
   }

   byte[] renderCurrent(byte[] var1) throws Exception {
      if (!this.failed && !this.awaitingResult && this.at < this.schedule.length) {
         int var2 = this.schedule[this.at].command;
         if (var2 >= 28 && !this.successWindowConfirmed) {
            this.failed = true;
            throw new IOException("successful code-window branch unconfirmed");
         } else {
            try {
               byte[] var3 = OfflineRenderer.renderCandidate(var2, var1, this.frames, this.rules, this.shapes, this.guards, this.pins, this.markerPlan, this.markerWords, this.writeSites);
               this.pendingInstructionCount = (var3[0] & 255) << 8 | var3[1] & 255;
               this.awaitingResult = true;
               return var3;
            } catch (Exception var4) {
               this.failed = true;
               throw var4;
            }
         }
      } else {
         throw new IOException("ledger out of order");
      }
   }

   void acceptResult(byte[] var1) throws Exception {
      if (!this.failed && this.awaitingResult && this.at < this.schedule.length) {
         int var2 = this.schedule[this.at].nextResultRequest;
         if (var2 == 65535) {
            this.failed = true;
            throw new IOException("terminal command must not return a result");
         } else {
            try {
               OfflineRenderer.Frame var3 = OfflineRenderer.frame(var1);
               OfflineRenderer.verifyNewResult(var2, var3, this.shapes, this.guards);
               OfflineRenderer.verifyMarkerNewResult(var2, var3, this.markerWords);
               if (this.frames[var2] != null) {
                  throw new IOException("duplicate result request");
               } else {
                  this.frames[var2] = var3;
                  if (var2 == 27) {
                     this.successWindowConfirmed = true;
                  }

                  ++this.at;
                  this.awaitingResult = false;
               }
            } catch (Exception var4) {
               this.failed = true;
               throw var4;
            }
         }
      } else {
         throw new IOException("ledger result out of order");
      }
   }

   void finishTerminal(byte[] var1) throws Exception {
      if (!this.failed && this.awaitingResult && this.at == this.schedule.length - 1 && this.schedule[this.at].nextResultRequest == 65535) {
         try {
            OfflineRenderer.Frame var2 = OfflineRenderer.frame(var1);
            if (var2.status != 0L || var2.instruction != this.pendingInstructionCount || var2.scalars.length != 0 || var2.vectors.length != 0) {
               throw new IOException("terminal Boot result changed");
            }
         } catch (Exception var3) {
            this.failed = true;
            throw var3;
         }

         ++this.at;
         this.awaitingResult = false;
      } else {
         this.failed = true;
         throw new IOException("terminal finish out of order");
      }
   }

   boolean complete() {
      return !this.failed && !this.awaitingResult && this.at == this.schedule.length;
   }

   boolean successWindowConfirmed() {
      return this.successWindowConfirmed;
   }
}
