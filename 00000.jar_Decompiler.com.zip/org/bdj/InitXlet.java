package org.bdj;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.security.MessageDigest;
import javax.tv.xlet.Xlet;
import javax.tv.xlet.XletContext;
import javax.tv.xlet.XletStateChangeException;
import org.havi.ui.HComponent;
import org.havi.ui.HScene;
import org.havi.ui.HSceneFactory;

public final class InitXlet implements Xlet, Runnable, KeyListener {
   private static final String[][] CLASSES = new String[][]{{"J196rR", "f59953027867d15d1434179991feeeb94bf274422f742e739067fd65400a264d"}, {"AXZXkk", "2362afc9efa07a688169b9121d9e5f8bdacbead58f87cafd23fdddffea58b429"}, {"EkIKZR", "df30bfbd25c3cdbe67965d907d575efb562738cf29c258895a698ff2ef525137"}, {"Hx1400", "e597710078e9afab5b24f4c22ea31fe7e5a5643b602b06c2866273b61c9c57e9"}};
   private static final String HEN_SHA256 = "29ec095fbede651e29954de43411599093138791e62105aaee6fdced58edec06";
   private static final String[][] META = new String[][]{{"rules.bin", "9c2f599212bfa71e1026dcc25b2f78826245992f958d898f7d0a1b6a2c2cb66e", "5338"}, {"shapes.bin", "a88a4eec4b49119c5e197b83b6c11724116f1c4f0057039b388874277c258050", "794"}, {"guards.bin", "64026f18135fe03397e0a2eb9c2586ce9218b1ed7b8cb6b13789ca8a2e367f50", "184"}, {"schedule.bin", "63b7a01ee102194aedd6329e750c6000752d076e1ebc5c18b7a3d0020ef49463", "168"}, {"template-hashes.bin", "9b60da9a7ce6a46327aed2091bafd7aaf182ed3a3e64aa5508fb39c02d8f5abc", "1528"}, {"marker-sites.bin", "816859ef11826205f0459b5246eff9dac3e02ccc4c54e4496eacc8bf9c3863bf", "40"}, {"write-sites.bin", "4bae0f1ad26b53efb4c47a12b8923191f0d99b52f7e4b792b82df2494f97276f", "656"}};
   private static final String HEN_SENTINEL = "file:/__bonk___offline_missing__/hen.bin";
   private Container scene;
   private Lines lines;
   private volatile boolean stopped;
   private volatile boolean ready;
   private boolean preflightStarted;
   private boolean attempted;
   private String discRoot;
   private String henUrl;
   private OfflineRenderer.Rule[] rules;
   private OfflineRenderer.Shape[] shapes;
   private OfflineRenderer.Guards guards;
   private OfflineRenderer.ScheduleEntry[] schedule;
   private OfflineRenderer.TemplatePin[] pins;
   private OfflineRenderer.MarkerPlan markerPlan;
   private OfflineRenderer.WriteSite[] writeSites;
   // $FF: synthetic field
   static Class class$0;

   public void initXlet(XletContext var1) throws XletStateChangeException {
      this.stopped = false;
   }

   public synchronized void startXlet() throws XletStateChangeException {
      this.stopped = false;
      if (this.scene == null) {
         this.openDisplay();
      } else {
         this.scene.setVisible(true);
      }

      if (!this.preflightStarted && !this.ready && !this.attempted) {
         this.preflightStarted = true;
         Thread var1 = new Thread(this, "Bonk HEN local asset preflight");
         var1.setDaemon(true);
         var1.start();
      }

   }

   public void pauseXlet() {
      this.stopped = true;
      if (this.scene != null) {
         this.scene.setVisible(false);
      }

   }

   public void destroyXlet(boolean var1) throws XletStateChangeException {
      this.stopped = true;
      if (this.scene != null) {
         this.scene.setVisible(false);
      }

      this.scene = null;
      this.lines = null;
   }

   public void run() {
      try {
         this.line("Credits: Kat (@avieah), Slopp (@slopp), and Pigeon (@daburningpigeon) on Discord");
         Class var10000 = class$0;
         if (var10000 == null) {
            try {
               var10000 = Class.forName("org.bdj.InitXlet");
            } catch (ClassNotFoundException var11) {
               throw new NoClassDefFoundError(((Throwable)var11).getMessage());
            }

            class$0 = var10000;
         }

         URL var1 = var10000.getResource("InitXlet.class");
         if (var1 == null) {
            throw new IOException("signed Xlet URL missing");
         }

         String var2 = var1.toString();
         int var3 = var2.indexOf("/BDMV/JAR/");
         if (!var2.startsWith("jar:file:") || var3 < 0) {
            throw new IOException("Xlet is not in a disc JAR");
         }

         this.discRoot = var2.substring(4, var3);
         if (!this.discRoot.startsWith("file:")) {
            throw new IOException("disc root is not local file URL");
         }

         int var4 = 0;

         while(true) {
            if (var4 >= CLASSES.length) {
               this.line("Four local helper classes verified");
               var10000 = class$0;
               if (var10000 == null) {
                  try {
                     var10000 = Class.forName("org.bdj.InitXlet");
                  } catch (ClassNotFoundException var10) {
                     throw new NoClassDefFoundError(((Throwable)var10).getMessage());
                  }

                  class$0 = var10000;
               }
               break;
            }

            URL var5 = new URL(this.discRoot + "/x/offline/" + CLASSES[var4][0] + ".class");
            checkHash(var5, CLASSES[var4][1], 1, 100000);
            ++var4;
         }

         URL var13 = var10000.getResource("/bonk/hen.bin");
         if (var13 == null || !var13.toString().startsWith("jar:file:")) {
            throw new IOException("signed local HEN URL missing");
         }

         checkHash(var13, "29ec095fbede651e29954de43411599093138791e62105aaee6fdced58edec06", 562240, 562240);
         this.henUrl = var13.toString();
         this.line("Exact HEN image verified in signed JAR");
         byte[][] var14 = new byte[META.length][];
         int var6 = 0;

         while(var6 < META.length) {
            var10000 = class$0;
            if (var10000 == null) {
               try {
                  var10000 = Class.forName("org.bdj.InitXlet");
               } catch (ClassNotFoundException var9) {
                  throw new NoClassDefFoundError(((Throwable)var9).getMessage());
               }

               class$0 = var10000;
            }

            URL var7 = var10000.getResource("/bonk/local/" + META[var6][0]);
            if (var7 != null && var7.toString().startsWith("jar:file:")) {
               var14[var6] = readBounded(var7, 8192);
               if (var14[var6].length == Integer.parseInt(META[var6][2]) && hexHash(var14[var6]).equals(META[var6][1])) {
                  ++var6;
                  continue;
               }

               throw new IOException("local metadata identity changed");
            }

            throw new IOException("local metadata resource missing");
         }

         this.rules = OfflineRenderer.rules(var14[0]);
         this.shapes = OfflineRenderer.shapes(var14[1]);
         this.guards = OfflineRenderer.guards(var14[2]);
         this.schedule = OfflineRenderer.schedule(var14[3]);
         this.pins = OfflineRenderer.templatePins(var14[4]);
         this.markerPlan = OfflineRenderer.markerPlan(var14[5]);
         this.writeSites = OfflineRenderer.writeSites(var14[6], this.rules);
         if (this.pins.length != this.schedule.length) {
            throw new IOException("command schedule count changed");
         }

         for(int var15 = 0; var15 < this.pins.length; ++var15) {
            if (this.pins[var15].command != this.schedule[var15].command) {
               throw new IOException("command schedule identity changed");
            }
         }

         for(int var16 = 0; var16 < this.pins.length; ++var16) {
            byte[] var17 = this.loadTemplate(this.pins[var16].command, this.pins[var16].length);
            byte[] var8 = MessageDigest.getInstance("SHA-256").digest(var17);
            if (!same(var8, this.pins[var16].sha256)) {
               throw new IOException("command template hash changed");
            }
         }

         this.line("All 40 local command templates verified");
         if (this.stopped) {
            return;
         }

         this.ready = true;
         this.line("LOCAL PREFLIGHT PASS. Press X once to run.");
         this.line("One attempt only; restart after any failure.");
      } catch (Throwable var12) {
         this.line("PREFLIGHT FAIL: " + var12.getClass().getName());
         if (var12.getMessage() != null) {
            this.line(var12.getMessage());
         }
      }

   }

   public void keyPressed(KeyEvent var1) {
      int var2 = var1.getKeyCode();
      if (var2 == 10 || var2 == 32 || var2 == 88) {
         synchronized(this) {
            if (this.stopped || !this.ready || this.attempted) {
               return;
            }

            this.attempted = true;
         }

         this.line("Attempt 1 started: local interpreter commands");
         Thread var3 = new Thread(new Attempt((Attempt)null), "Bonk HEN one-shot local run");
         var3.setDaemon(true);
         var3.start();
         var1.consume();
      }
   }

   public void keyReleased(KeyEvent var1) {
   }

   public void keyTyped(KeyEvent var1) {
   }

   private void showEarlyStatus(int var1, byte[] var2) {
      try {
         OfflineRenderer.Frame var3 = OfflineRenderer.frame(var2);
         if (var3.vectors.length == 0 || var3.vectors[0].length < 4) {
            throw new IOException("early status vector missing");
         }

         int var4 = readInt(var3.vectors[0], 0);
         if (var1 == 6) {
            if (var4 == -1) {
               this.line("Marker scan: no match (-1)");
            } else if (var4 == -2) {
               this.line("Marker scan: helper exception (-2)");
            } else {
               this.line("Marker scan index: " + var4);
            }
         } else if (var1 != 4 && var1 != 5) {
            this.line("Command 2 helper status: " + var4);
         } else {
            if (var3.vectors[0].length < 8) {
               throw new IOException("early status pair missing");
            }

            int var5 = readInt(var3.vectors[0], 4);
            this.line("Command " + var1 + " helper status: " + var4 + ", " + var5);
         }
      } catch (Throwable var6) {
         this.line("Command " + var1 + " early status unreadable");
      }

   }

   private void showHxDiagnostic(byte[] var1) {
      try {
         OfflineRenderer.Frame var2 = OfflineRenderer.frame(var1);
         if (var2.vectors.length != 2 || var2.vectors[0].length > 4096 || var2.vectors[1].length > 131072) {
            throw new IOException("Hx diagnostic shape changed");
         }

         String var3 = new String(var2.vectors[0], "UTF-8");
         this.line("Hx summary: " + printable(var3, 96));
         String var4 = new String(var2.vectors[1], "UTF-8");
         String[] var5 = new String[3];
         int var6 = 0;

         int var8;
         for(int var7 = 0; var7 < var4.length(); var7 = var8 + 1) {
            var8 = var4.indexOf(10, var7);
            if (var8 < 0) {
               var8 = var4.length();
            }

            String var9 = var4.substring(var7, var8);
            if (var9.indexOf("STOP") >= 0 || var9.indexOf("no pair") >= 0 || var9.indexOf("K NOT fully applied") >= 0 || var9.indexOf("G2 sysfilt_ops") >= 0 || var9.indexOf("safeDown threw") >= 0 || var9.indexOf("H7 pthread_create") >= 0 || var9.indexOf("H7 ***") >= 0 || var9.indexOf("L set ") >= 0) {
               var5[var6 % var5.length] = printable(var9, 96);
               ++var6;
            }
         }

         var8 = var6 < var5.length ? var6 : var5.length;

         for(int var12 = 0; var12 < var8; ++var12) {
            this.line("Hx log: " + var5[(var6 - var8 + var12) % var5.length]);
         }
      } catch (Throwable var10) {
         this.line("Hx report could not be decoded for display");
      }

   }

   private static String printable(String var0, int var1) {
      StringBuffer var2 = new StringBuffer();

      for(int var3 = 0; var3 < var0.length() && var2.length() < var1; ++var3) {
         char var4 = var0.charAt(var3);
         var2.append(var4 >= ' ' && var4 <= '~' ? var4 : ' ');
      }

      return var2.toString();
   }

   private byte[] loadTemplate(int var1, int var2) throws Exception {
      String var3;
      for(var3 = Integer.toString(var1); var3.length() < 4; var3 = "0" + var3) {
      }

      Class var10000 = class$0;
      if (var10000 == null) {
         try {
            var10000 = Class.forName("org.bdj.InitXlet");
         } catch (ClassNotFoundException var6) {
            throw new NoClassDefFoundError(((Throwable)var6).getMessage());
         }

         class$0 = var10000;
      }

      URL var4 = var10000.getResource("/bonk/local/templates/cmd-" + var3 + ".bin");
      if (var4 != null && var4.toString().startsWith("jar:file:")) {
         byte[] var5 = readBounded(var4, var2);
         if (var5.length != var2) {
            throw new IOException("command template length changed");
         } else {
            return var5;
         }
      } else {
         throw new IOException("command template resource missing");
      }
   }

   static byte[] patchLocalHenUrl(byte[] var0, String var1) throws Exception {
      if (var1 != null && var1.startsWith("jar:file:") && var1.indexOf("!/bonk/hen.bin") >= 0) {
         byte[] var2 = "file:/__bonk___offline_missing__/hen.bin".getBytes("UTF-8");
         byte[] var3 = var1.getBytes("UTF-8");
         int var4 = -1;

         for(int var5 = 13; var5 <= var0.length - var2.length; ++var5) {
            boolean var6 = true;

            for(int var7 = 0; var7 < var2.length; ++var7) {
               if (var0[var5 + var7] != var2[var7]) {
                  var6 = false;
                  break;
               }
            }

            if (var6) {
               if (var4 >= 0) {
                  throw new IOException("HEN sentinel not unique");
               }

               var4 = var5;
            }
         }

         if (var4 >= 13 && var0[var4 - 13] == 5 && readLong(var0, var4 - 12) == 45L && readInt(var0, var4 - 4) == var2.length) {
            int var9 = var0.length - var2.length + var3.length;
            if (var9 > 65535) {
               throw new IOException("local HEN command too long");
            } else {
               byte[] var10 = new byte[var9];
               System.arraycopy(var0, 0, var10, 0, var4);
               System.arraycopy(var3, 0, var10, var4, var3.length);
               System.arraycopy(var0, var4 + var2.length, var10, var4 + var3.length, var0.length - var4 - var2.length);
               int var11 = var4 - 4;
               int var8 = var3.length;
               var10[var11] = (byte)(var8 >>> 24);
               var10[var11 + 1] = (byte)(var8 >>> 16);
               var10[var11 + 2] = (byte)(var8 >>> 8);
               var10[var11 + 3] = (byte)var8;
               return var10;
            }
         } else {
            throw new IOException("HEN assignment framing changed");
         }
      } else {
         throw new IOException("HEN URL is not verified local JAR resource");
      }
   }

   private static long readLong(byte[] var0, int var1) {
      long var2 = 0L;

      for(int var4 = 0; var4 < 8; ++var4) {
         var2 = var2 << 8 | (long)var0[var1 + var4] & 255L;
      }

      return var2;
   }

   private static int readInt(byte[] var0, int var1) {
      int var2 = 0;

      for(int var3 = 0; var3 < 4; ++var3) {
         var2 = var2 << 8 | var0[var1 + var3] & 255;
      }

      return var2;
   }

   private static byte[] readBounded(URL var0, int var1) throws Exception {
      InputStream var2 = var0.openStream();
      ByteArrayOutputStream var3 = new ByteArrayOutputStream();

      try {
         byte[] var4 = new byte[8192];

         int var5;
         while((var5 = var2.read(var4)) >= 0) {
            if (var5 != 0) {
               if (var3.size() > var1 - var5) {
                  throw new IOException("asset exceeds bound");
               }

               var3.write(var4, 0, var5);
            }
         }
      } finally {
         var2.close();
      }

      return var3.toByteArray();
   }

   static void checkHash(URL var0, String var1, int var2, int var3) throws Exception {
      if (var2 >= 0 && var3 >= var2) {
         InputStream var4 = var0.openStream();
         MessageDigest var5 = MessageDigest.getInstance("SHA-256");
         byte[] var6 = new byte[8192];
         int var7 = 0;
         int var8 = 0;

         int var9;
         try {
            while((var9 = var4.read(var6)) >= 0) {
               if (var9 == 0) {
                  ++var8;
                  if (var8 > 16) {
                     throw new IOException("asset stream did not advance");
                  }
               } else {
                  var8 = 0;
                  if (var7 > var3 - var9) {
                     throw new IOException("asset exceeds bound");
                  }

                  var5.update(var6, 0, var9);
                  var7 += var9;
               }
            }
         } finally {
            var4.close();
         }

         if (var7 < var2 || !hexDigest(var5.digest()).equals(var1)) {
            throw new IOException("asset hash or size changed");
         }
      } else {
         throw new IOException("asset size bounds invalid");
      }
   }

   private static String hexHash(byte[] var0) throws Exception {
      return hexDigest(MessageDigest.getInstance("SHA-256").digest(var0));
   }

   private static String hexDigest(byte[] var0) {
      StringBuffer var1 = new StringBuffer(64);

      for(int var2 = 0; var2 < var0.length; ++var2) {
         int var3 = var0[var2] & 255;
         if (var3 < 16) {
            var1.append('0');
         }

         var1.append(Integer.toHexString(var3));
      }

      return var1.toString();
   }

   private static boolean same(byte[] var0, byte[] var1) {
      if (var0.length != var1.length) {
         return false;
      } else {
         int var2 = 0;

         for(int var3 = 0; var3 < var0.length; ++var3) {
            var2 |= var0[var3] ^ var1[var3];
         }

         return var2 == 0;
      }
   }

   private void openDisplay() {
      HScene var1 = HSceneFactory.getInstance().getDefaultHScene();
      if (var1 != null) {
         ((Container)var1).setLayout((LayoutManager)null);
         ((Container)var1).setBackground(Color.black);
         Lines var2 = new Lines((Lines)null);
         var2.setBounds(0, 0, ((Container)var1).getWidth() > 0 ? ((Container)var1).getWidth() : 1280, ((Container)var1).getHeight() > 0 ? ((Container)var1).getHeight() : 720);
         var2.addKeyListener(this);
         ((Container)var1).addKeyListener(this);
         ((Container)var1).add(var2);
         ((Container)var1).setVisible(true);
         ((Container)var1).validate();
         var2.requestFocus();
         this.scene = var1;
         this.lines = var2;
      }
   }

   private void line(String var1) {
      if (!this.stopped) {
         System.out.println("Bonk HEN local: " + var1);
         Lines var2 = this.lines;
         if (var2 != null) {
            var2.addLine(var1);
         }

      }
   }

   private final class Attempt implements Runnable {
      private Attempt() {
      }

      public void run() {
         int var1 = 0;
         Object var2 = null;
         Object var3 = null;
         byte var4 = 0;

         try {
            if (InitXlet.this.stopped) {
               throw new IOException("Xlet stopped");
            }

            Boot.EP = InitXlet.this.discRoot;
            Boot.SID = "offline";
            Class var10000 = InitXlet.class$0;
            if (var10000 == null) {
               try {
                  var10000 = Class.forName("org.bdj.InitXlet");
               } catch (ClassNotFoundException var15) {
                  throw new NoClassDefFoundError(((Throwable)var15).getMessage());
               }

               InitXlet.class$0 = var10000;
            }

            Boot.PAR = var10000.getClassLoader();
            Boot.SK = null;
            int[] var5 = OfflineRenderer.freshMarkerWords();
            LocalResultLedger var6 = new LocalResultLedger(InitXlet.this.schedule, InitXlet.this.rules, InitXlet.this.shapes, InitXlet.this.guards, InitXlet.this.pins, InitXlet.this.markerPlan, var5, InitXlet.this.writeSites);

            for(int var7 = 0; var7 < InitXlet.this.schedule.length; ++var7) {
               if (InitXlet.this.stopped) {
                  throw new IOException("Xlet stopped");
               }

               var1 = var6.currentCommand();
               byte[] var8 = InitXlet.this.loadTemplate(var1, InitXlet.this.pins[var7].length);
               byte[] var9 = var6.renderCurrent(var8);
               if (var1 == 32) {
                  var9 = InitXlet.patchLocalHenUrl(var9, InitXlet.this.henUrl);
                  InitXlet.this.line("Command 32 uses verified local HEN URL");
               }

               if (var1 == 28) {
                  InitXlet.this.line("Native code-window branch verified");
               }

               if (var1 == 43) {
                  InitXlet.this.line("Entering one-shot Hx/HEN stage");
               }

               if (var1 != 44) {
                  byte[] var18 = Boot.exec(var9);
                  if (var1 == 2 || var1 == 4 || var1 == 5 || var1 == 6) {
                     ;
                  }

                  if (InitXlet.this.schedule[var7].nextResultRequest == 65535) {
                     var6.finishTerminal(var18);
                  } else {
                     var6.acceptResult(var18);
                  }
               } else {
                  long var10 = System.currentTimeMillis() + 45000L;
                  boolean var12 = false;
                  int var13 = 1;

                  while(true) {
                     if (var13 <= 10) {
                        byte[] var14 = Boot.exec(var9);
                        if (OfflineRenderer.isPendingHenResult(var14)) {
                           InitXlet.this.line("Hx still running; read-only status " + var13);
                           if (var13 == 10 || System.currentTimeMillis() > var10) {
                              throw new IOException("Hx status remained pending");
                           }

                           ++var13;
                           continue;
                        }

                        var6.acceptResult(var14);
                        var12 = true;
                     }

                     if (!var12) {
                        throw new IOException("Hx final report missing");
                     }
                     break;
                  }
               }

               if (var1 == 9 || var1 == 27 || var1 == 32 || var1 == 44 || var1 == 46) {
                  InitXlet.this.line("Command " + var1 + " result accepted");
               }
            }

            if (!var6.complete()) {
               throw new IOException("local result ledger incomplete");
            }

            InitXlet.this.line("Hx reports HEN start. Verify menu and kernel R/W separately.");
         } catch (Throwable var16) {
            InitXlet.this.line("STOP at command " + var1 + ": " + var16.getClass().getName());
            if (var16.getMessage() != null) {
               InitXlet.this.line(var16.getMessage());
            }

            if (var1 == var4 && var3 != null) {
               InitXlet.this.showEarlyStatus(var1, (byte[])var3);
            }

            if (var1 == 44 && var2 != null) {
               InitXlet.this.showHxDiagnostic((byte[])var2);
            }

            InitXlet.this.line("No retry in this boot. Cold reboot before another attempt.");
         }

      }

      // $FF: synthetic method
      Attempt(Attempt var2) {
         this();
      }
   }

   private static final class Lines extends HComponent {
      private static final long serialVersionUID = 1L;
      private final String[] values;
      private int count;

      private Lines() {
         this.values = new String[15];
      }

      synchronized void addLine(String var1) {
         if (this.count < this.values.length) {
            this.values[this.count++] = var1;
         } else {
            for(int var2 = 1; var2 < this.values.length; ++var2) {
               this.values[var2 - 1] = this.values[var2];
            }

            this.values[this.values.length - 1] = var1;
         }

         this.repaint();
      }

      public synchronized void paint(Graphics var1) {
         var1.setColor(Color.black);
         var1.fillRect(0, 0, this.getWidth(), this.getHeight());
         var1.setColor(new Color(255, 127, 0));
         var1.setFont(new Font("SansSerif", 1, 28));
         var1.drawString("BONK HEN 14.00", 40, 55);
         var1.setColor(Color.white);
         var1.setFont(new Font("SansSerif", 0, 21));

         for(int var2 = 0; var2 < this.count; ++var2) {
            var1.drawString(this.values[var2], 40, 105 + var2 * 34);
         }

      }

      // $FF: synthetic method
      Lines(Lines var1) {
         this();
      }
   }
}
