package org.bdj;

import java.awt.Color;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.StringTokenizer;
import java.util.Vector;

public class Screen extends Container {
   private static final long serialVersionUID = 4702111234474983745L;
   private final Font FONT = new Font((String)null, 0, 17);
   private final Vector messages = new Vector();
   private static final Screen instance = new Screen();
   private volatile boolean isPainting = false;
   private volatile boolean isDirty = false;
   private volatile boolean isVisible = true;

   private Screen() {
      this.setBackground(Color.BLACK);
      this.setForeground(Color.WHITE);
      this.addComponentListener(new ComponentAdapter() {
         public void componentShown(ComponentEvent var1) {
            Screen.this.isVisible = true;
            Screen.this.safeRepaint();
         }

         public void componentHidden(ComponentEvent var1) {
            Screen.this.isVisible = false;
         }
      });
   }

   public static Screen getInstance() {
      return instance;
   }

   public static void println(String var0) {
      println(var0, true, false);
   }

   public static void println(String var0, boolean var1, boolean var2) {
      getInstance().print(var0, var1, var2);
   }

   public void print(String var1, boolean var2, boolean var3) {
      if (var1 == null) {
         var1 = "null";
      }

      synchronized(this.messages) {
         if (var3 && this.messages.size() > 0) {
            this.messages.removeElementAt(this.messages.size() - 1);
         }

         this.messages.addElement(var1);

         while(this.messages.size() > 46) {
            this.messages.removeElementAt(0);
         }

         this.isDirty = true;
      }

      if (var2) {
         this.safeRepaint();
      }

   }

   private void safeRepaint() {
      if (EventQueue.isDispatchThread()) {
         if (this.isDisplayable()) {
            this.repaint();
         }
      } else {
         EventQueue.invokeLater(new Runnable() {
            public void run() {
               if (Screen.this.isDisplayable()) {
                  Screen.this.repaint();
               }

            }
         });
      }

   }

   public void update(Graphics var1) {
      this.paint(var1);
   }

   public static void printStackTrace(String var0, Throwable var1) {
      println(var0, true, false);
      getInstance().printStackTrace(var1);
   }

   public void printStackTrace(Throwable var1) {
      if (var1 == null) {
         this.print("null exception", true, false);
      } else {
         try {
            StringWriter var4 = new StringWriter();

            StringTokenizer var2;
            StringBuffer var3;
            try {
               PrintWriter var5 = new PrintWriter(var4);

               try {
                  var1.printStackTrace(var5);
                  var5.flush();
               } finally {
                  var5.close();
               }

               String var6 = var4.toString();
               var2 = new StringTokenizer(var6, "\n", false);
               var3 = new StringBuffer(var6.length());
            } finally {
               var4.close();
            }

            Vector var22 = new Vector();

            while(var2.hasMoreTokens()) {
               String var23 = var2.nextToken();
               var3.setLength(0);

               for(int var7 = 0; var7 < var23.length(); ++var7) {
                  char var8 = var23.charAt(var7);
                  if (var8 == '\t') {
                     var3.append("   ");
                  } else if (var8 != '\r') {
                     var3.append(var8);
                  }
               }

               var22.addElement(var3.toString());
            }

            synchronized(this.messages) {
               for(int var24 = 0; var24 < var22.size(); ++var24) {
                  String var25 = (String)var22.elementAt(var24);
                  this.print(var25, false, false);
               }
            }

            this.safeRepaint();
         } catch (IOException var21) {
            this.printThrowable(var1);
            throw new RuntimeException("Another exception occurred while printing stacktrace. " + var21.getClass().getName() + ": " + var21.getMessage());
         }
      }
   }

   public void printThrowable(Throwable var1) {
      if (var1 == null) {
         this.print("null throwable", true, false);
      } else {
         String var2 = var1.getMessage();
         if (var2 == null) {
            var2 = "(no message)";
         }

         this.print(var1.getClass().getName() + ": " + var2, true, false);
      }
   }

   public void paint(Graphics var1) {
      if (var1 != null) {
         boolean var3 = false;
         Vector var2;
         synchronized(this.messages) {
            if (this.isPainting) {
               return;
            }

            this.isPainting = true;
            this.isDirty = false;
            var2 = new Vector(this.messages);
         }

         try {
            var1.setColor(this.getBackground());
            var1.fillRect(0, 0, this.getWidth(), this.getHeight());
            var1.setFont(this.FONT);
            var1.setColor(this.getForeground());
            int var4 = var1.getFontMetrics().getHeight();
            byte var5 = 8;
            int var6 = 23;

            for(int var7 = 0; var7 < var2.size(); ++var7) {
               String var8 = (String)var2.elementAt(var7);
               if (var8 != null && var6 < this.getHeight()) {
                  var1.drawString(var8, var5, var6);
                  var6 += var4;
               }
            }
         } finally {
            synchronized(this.messages) {
               this.isPainting = false;
               if (this.isDirty) {
                  var3 = true;
               }
            }

            if (var3) {
               this.safeRepaint();
            }

         }

      }
   }

   public static void clear() {
      getInstance().clearMessages();
   }

   public void clearMessages() {
      synchronized(this.messages) {
         this.messages.removeAllElements();
         this.isDirty = true;
      }

      this.safeRepaint();
   }
}
