package org.bdj;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.SecureRandom;

final class OfflineRenderer {
   static final int FRAME_LIMIT = 16777216;

   static Frame frame(byte[] var0) throws Exception {
      if (var0.length >= 20 && var0.length <= 16777216) {
         DataInputStream var1 = new DataInputStream(new ByteArrayInputStream(var0));
         long var2 = var1.readLong();
         int var4 = var1.readInt();
         int var5 = var1.readInt();
         if (var5 >= 0 && var5 <= 4096) {
            long[] var6 = new long[var5];

            for(int var7 = 0; var7 < var5; ++var7) {
               var6[var7] = var1.readLong();
            }

            int var11 = var1.readInt();
            if (var11 >= 0 && var11 <= 4096) {
               byte[][] var8 = new byte[var11][];

               for(int var9 = 0; var9 < var11; ++var9) {
                  int var10 = var1.readInt();
                  if (var10 < 0 || var10 > 16777216 || var10 > var1.available()) {
                     throw new IOException("vector length invalid");
                  }

                  var8[var9] = new byte[var10];
                  var1.readFully(var8[var9]);
               }

               if (var1.available() != 0) {
                  throw new IOException("result frame trailing bytes");
               } else {
                  return new Frame(var2, var4, var6, var8);
               }
            } else {
               throw new IOException("vector count invalid");
            }
         } else {
            throw new IOException("scalar count invalid");
         }
      } else {
         throw new IOException("result frame size invalid");
      }
   }

   static Rule[] rules(byte[] var0) throws Exception {
      DataInputStream var1 = metadata(var0, "FMR1");
      int var2 = var1.readUnsignedShort();
      if (var2 != 205) {
         throw new IOException("rule count changed");
      } else {
         Rule[] var3 = new Rule[var2];

         for(int var4 = 0; var4 < var2; ++var4) {
            var3[var4] = new Rule(var1.readUnsignedShort(), var1.readUnsignedShort(), var1.readInt(), var1.readUnsignedShort(), var1.readUnsignedShort(), var1.readUnsignedShort(), var1.readUnsignedShort(), var1.readUnsignedShort(), var1.readLong());
         }

         if (var1.available() != 0) {
            throw new IOException("rule trailing bytes");
         } else {
            return var3;
         }
      }
   }

   static Shape[] shapes(byte[] var0) throws Exception {
      DataInputStream var1 = metadata(var0, "FMS1");
      int var2 = var1.readUnsignedShort();
      if (var2 >= 1 && var2 <= 47) {
         Shape[] var3 = new Shape[var2];

         for(int var4 = 0; var4 < var2; ++var4) {
            int var5 = var1.readUnsignedShort();
            long var6 = var1.readLong();
            int var8 = var1.readInt();
            int var9 = var1.readUnsignedShort();
            int var10 = var1.readUnsignedShort();
            if (var9 > 4096 || var10 > 4096) {
               throw new IOException("shape count invalid");
            }

            int[] var11 = new int[var10];

            for(int var12 = 0; var12 < var10; ++var12) {
               var11[var12] = var1.readInt();
            }

            var3[var4] = new Shape(var5, var6, var8, var9, var11);
         }

         if (var1.available() != 0) {
            throw new IOException("shape trailing bytes");
         } else {
            return var3;
         }
      } else {
         throw new IOException("shape count invalid");
      }
   }

   static Guards guards(byte[] var0) throws Exception {
      DataInputStream var1 = metadata(var0, "FMG1");
      int var2 = var1.readUnsignedShort();
      if (var2 != 10) {
         throw new IOException("native guard count changed");
      } else {
         long[] var3 = new long[var2];

         for(int var4 = 0; var4 < var2; ++var4) {
            var3[var4] = var1.readLong();
         }

         byte[][] var6 = new byte[3][32];

         for(int var5 = 0; var5 < var6.length; ++var5) {
            var1.readFully(var6[var5]);
         }

         if (var1.available() != 0) {
            throw new IOException("guard trailing bytes");
         } else {
            return new Guards(var3, var6);
         }
      }
   }

   static TemplatePin[] templatePins(byte[] var0) throws Exception {
      DataInputStream var1 = metadata(var0, "FMT1");
      int var2 = var1.readUnsignedShort();
      if (var2 != 40) {
         throw new IOException("template count changed");
      } else {
         TemplatePin[] var3 = new TemplatePin[var2];

         for(int var4 = 0; var4 < var2; ++var4) {
            int var5 = var1.readUnsignedShort();
            int var6 = var1.readInt();
            if (var6 < 2 || var6 > 65535) {
               throw new IOException("template length invalid");
            }

            byte[] var7 = new byte[32];
            var1.readFully(var7);
            var3[var4] = new TemplatePin(var5, var6, var7);
         }

         if (var1.available() != 0) {
            throw new IOException("template trailing bytes");
         } else {
            return var3;
         }
      }
   }

   static ScheduleEntry[] schedule(byte[] var0) throws Exception {
      DataInputStream var1 = metadata(var0, "FMC1");
      int var2 = var1.readUnsignedShort();
      if (var2 != 40) {
         throw new IOException("schedule count changed");
      } else {
         ScheduleEntry[] var3 = new ScheduleEntry[var2];
         int var4 = 0;

         for(int var5 = 0; var5 < var2; ++var5) {
            int var6 = var1.readUnsignedShort();
            int var7 = var1.readUnsignedShort();
            if (var6 <= var4 || var7 <= var6 && var7 != 65535 || var7 == 65535 && var5 != var2 - 1) {
               throw new IOException("schedule ordering invalid");
            }

            var3[var5] = new ScheduleEntry(var6, var7);
            var4 = var6;
         }

         if (var3[var2 - 1].command == 46 && var3[var2 - 1].nextResultRequest == 65535 && var1.available() == 0) {
            return var3;
         } else {
            throw new IOException("schedule terminal changed");
         }
      }
   }

   static MarkerPlan markerPlan(byte[] var0) throws Exception {
      DataInputStream var1 = metadata(var0, "FMM1");
      int var2 = var1.readUnsignedShort();
      if (var2 != 4) {
         throw new IOException("marker site count changed");
      } else {
         int[] var3 = new int[var2];

         for(int var4 = 0; var4 < var2; ++var4) {
            int var5 = var1.readUnsignedShort();
            int var6 = var1.readUnsignedShort();
            var3[var4] = var1.readInt();
            if (var5 != 2 || var6 != 21 + var4 || var3[var4] < 18 || var4 > 0 && var3[var4] <= var3[var4 - 1]) {
               throw new IOException("marker site identity changed");
            }
         }

         if (var1.available() != 0) {
            throw new IOException("marker site trailing bytes");
         } else {
            return new MarkerPlan(var3);
         }
      }
   }

   static WriteSite[] writeSites(byte[] var0, Rule[] var1) throws Exception {
      DataInputStream var2 = metadata(var0, "FMW1");
      int var3 = var2.readUnsignedShort();
      if (var3 != 81) {
         throw new IOException("direct-write site count changed");
      } else {
         WriteSite[] var4 = new WriteSite[var3];

         for(int var5 = 0; var5 < var3; ++var5) {
            int var6 = var2.readUnsignedShort();
            int var7 = var2.readUnsignedShort();
            int var8 = var2.readInt();
            if (var6 < 1 || var6 > 28 || var8 < 2 || var5 > 0 && (var6 < var4[var5 - 1].command || var6 == var4[var5 - 1].command && var8 <= var4[var5 - 1].offset)) {
               throw new IOException("direct-write site order changed");
            }

            int var9 = 0;

            for(int var10 = 0; var10 < var1.length; ++var10) {
               if (var1[var10].command == var6 && var1[var10].instruction == var7 && var1[var10].offset == var8) {
                  ++var9;
               }
            }

            if (var9 != 1) {
               throw new IOException("direct-write site not a relocation");
            }

            var4[var5] = new WriteSite(var6, var7, var8);
         }

         if (var2.available() != 0) {
            throw new IOException("direct-write site trailing bytes");
         } else {
            return var4;
         }
      }
   }

   static int[] freshMarkerWords() throws IOException {
      SecureRandom var0 = new SecureRandom();
      int[] var1 = new int[4];

      for(int var2 = 0; var2 < var1.length; ++var2) {
         while(true) {
            var1[var2] = var0.nextInt();
            boolean var3 = var1[var2] != 0 && var1[var2] != -1 && var1[var2] != -2;

            for(int var4 = 0; var4 < var2; ++var4) {
               if (var1[var2] == var1[var4]) {
                  var3 = false;
               }
            }

            if (var3) {
               break;
            }
         }
      }

      validateMarkerWords(var1);
      return var1;
   }

   private static DataInputStream metadata(byte[] var0, String var1) throws IOException {
      DataInputStream var2 = new DataInputStream(new ByteArrayInputStream(var0));

      for(int var3 = 0; var3 < 4; ++var3) {
         if (var2.readUnsignedByte() != var1.charAt(var3)) {
            throw new IOException("metadata magic mismatch");
         }
      }

      if (var2.readUnsignedShort() != 1) {
         throw new IOException("metadata version unsupported");
      } else {
         return var2;
      }
   }

   static byte[] render(int var0, byte[] var1, Frame[] var2, Rule[] var3, Shape[] var4, Guards var5, TemplatePin[] var6) throws Exception {
      return renderInternal(var0, var1, var2, var3, var4, var5, var6, (MarkerPlan)null, (int[])null, (WriteSite[])null, false);
   }

   static byte[] renderCandidate(int var0, byte[] var1, Frame[] var2, Rule[] var3, Shape[] var4, Guards var5, TemplatePin[] var6, MarkerPlan var7, int[] var8, WriteSite[] var9) throws Exception {
      return renderInternal(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, true);
   }

   private static byte[] renderInternal(int var0, byte[] var1, Frame[] var2, Rule[] var3, Shape[] var4, Guards var5, TemplatePin[] var6, MarkerPlan var7, int[] var8, WriteSite[] var9, boolean var10) throws Exception {
      TemplatePin var11 = null;

      for(int var12 = 0; var12 < var6.length; ++var12) {
         if (var6[var12].command == var0) {
            var11 = var6[var12];
         }
      }

      if (var11 != null && var1.length == var11.length && same(hash(var1), var11.sha256)) {
         if (var10) {
            if (var7 == null) {
               throw new IOException("marker plan missing");
            }

            validateMarkerWords(var8);
            verifyPriorMarkerResults(var2, var0, var8);
         }

         verifyShapes(var2, var4, var0);
         if (var0 >= 12) {
            verifyNativeLayout(var2[12], var5);
         }

         if (var0 >= 17) {
            verifyAliases(var2[16]);
         }

         if (var0 >= 27) {
            verifyCodeWindows(var2[27], var5);
         }

         byte[] var19 = (byte[])var1.clone();

         for(int var13 = 0; var13 < var3.length; ++var13) {
            Rule var14 = var3[var13];
            if (var14.command == var0) {
               if (var14.offset < 2 || var14.offset + 8 > var19.length || var14.request > var0 || var14.request >= var2.length) {
                  throw new IOException("relocation site invalid");
               }

               if (var10) {
                  for(int var15 = 0; var15 < 8; ++var15) {
                     if (var19[var14.offset + var15] != 0) {
                        throw new IOException("captured relocation operand retained");
                     }
                  }
               }

               Frame var20 = var2[var14.request];
               if (var20 == null) {
                  throw new IOException("relocation source missing");
               }

               long var16 = value(var14, var20, var2);

               for(int var18 = 7; var18 >= 0; --var18) {
                  var19[var14.offset + var18] = (byte)((int)var16);
                  var16 >>>= 8;
               }
            }
         }

         if (var10 && var0 == 2) {
            patchMarkerWords(var19, var7, var8);
         }

         if (var10) {
            verifyWriteDestinations(var0, var19, var9);
         }

         return var19;
      } else {
         throw new IOException("template identity changed");
      }
   }

   static void verifyWriteDestinations(int var0, byte[] var1, WriteSite[] var2) throws IOException {
      if (var2 != null && var2.length == 81) {
         for(int var3 = 0; var3 < var2.length; ++var3) {
            WriteSite var4 = var2[var3];
            if (var4.command == var0) {
               if (var4.offset < 2 || var4.offset + 8 > var1.length) {
                  throw new IOException("direct-write destination site invalid");
               }

               long var5 = readLong(var1, var4.offset);
               if (var5 < 4294967296L || var5 >= 9223372036854775799L) {
                  throw new IOException("direct-write destination outside pointer range");
               }
            }
         }

      } else {
         throw new IOException("direct-write guard missing");
      }
   }

   static boolean isPendingHenResult(byte[] var0) throws Exception {
      Frame var1 = frame(var0);
      if (var1.status == 0L && var1.instruction == 7 && var1.scalars.length == 0 && var1.vectors.length == 2) {
         byte[] var2 = var1.vectors[0];
         byte[] var3 = "not run".getBytes("US-ASCII");
         if (var2.length != var3.length) {
            return false;
         } else {
            for(int var4 = 0; var4 < var3.length; ++var4) {
               if (var2[var4] != var3[var4]) {
                  return false;
               }
            }

            if (var1.vectors[1].length > 131072) {
               throw new IOException("Hx pending log too large");
            } else {
               return true;
            }
         }
      } else {
         throw new IOException("Hx status frame shape changed");
      }
   }

   private static void validateMarkerWords(int[] var0) throws IOException {
      if (var0 != null && var0.length == 4) {
         for(int var1 = 0; var1 < var0.length; ++var1) {
            if (var0[var1] == 0 || var0[var1] == -1 || var0[var1] == -2) {
               throw new IOException("reserved marker value");
            }

            for(int var2 = 0; var2 < var1; ++var2) {
               if (var0[var1] == var0[var2]) {
                  throw new IOException("duplicate marker value");
               }
            }
         }

      } else {
         throw new IOException("marker words missing");
      }
   }

   private static void patchMarkerWords(byte[] var0, MarkerPlan var1, int[] var2) throws IOException {
      for(int var3 = 0; var3 < 4; ++var3) {
         int var4 = var1.offsets[var3];
         if (var4 + 8 > var0.length || var0[var4 - 18] != 17 || var0[var4 - 1] != 1 || readLong(var0, var4 - 17) != 3L || readLong(var0, var4 - 9) != (long)var3) {
            throw new IOException("marker assignment structure changed");
         }

         for(int var5 = 0; var5 < 8; ++var5) {
            if (var0[var4 + var5] != 0) {
               throw new IOException("captured marker retained");
            }
         }

         long var8 = (long)var2[var3];

         for(int var7 = 7; var7 >= 0; --var7) {
            var0[var4 + var7] = (byte)((int)var8);
            var8 >>>= 8;
         }
      }

   }

   private static long readLong(byte[] var0, int var1) {
      long var2 = 0L;

      for(int var4 = 0; var4 < 8; ++var4) {
         var2 = var2 << 8 | (long)var0[var1 + var4] & 255L;
      }

      return var2;
   }

   private static int readInt(byte[] var0, int var1) {
      int var2 = 0;

      for(int var3 = 0; var3 < 4; ++var3) {
         var2 = var2 << 8 | var0[var1 + var3] & 255;
      }

      return var2;
   }

   private static void verifyPriorMarkerResults(Frame[] var0, int var1, int[] var2) throws IOException {
      if (var1 >= 7) {
         if (var0.length <= 7 || var0[7] == null) {
            throw new IOException("marker scan result missing");
         }

         verifyMarkerNewResult(7, var0[7], var2);
      }

      if (var1 >= 8) {
         if (var0.length <= 8 || var0[8] == null) {
            throw new IOException("marker echo result missing");
         }

         verifyMarkerNewResult(8, var0[8], var2);
      }

   }

   static void verifyMarkerNewResult(int var0, Frame var1, int[] var2) throws IOException {
      validateMarkerWords(var2);
      if (var0 == 7) {
         if (var1.vectors.length != 1 || var1.vectors[0].length != 4) {
            throw new IOException("marker scan failed");
         }

         int var3 = readInt(var1.vectors[0], 0);
         if (var3 < 4 || var3 > 16383) {
            throw new IOException("marker scan outside valid search range");
         }
      } else if (var0 == 8) {
         if (var1.vectors.length != 1 || var1.vectors[0].length != 1024) {
            throw new IOException("marker echo vector changed");
         }

         for(int var4 = 0; var4 < 4; ++var4) {
            if (readInt(var1.vectors[0], var4 * 4) != var2[var4]) {
               throw new IOException("marker echo mismatch");
            }
         }
      }

   }

   private static long value(Rule var0, Frame var1, Frame[] var2) throws IOException {
      long var3;
      if (var0.kind == 0) {
         if (var0.slot >= var1.scalars.length) {
            throw new IOException("scalar source missing");
         }

         var3 = var1.scalars[var0.slot];
      } else if (var0.kind == 1) {
         if (var0.slot >= var1.vectors.length) {
            throw new IOException("vector source missing");
         }

         var3 = qword(var1.vectors[var0.slot], var0.high, var0.low);
      } else {
         if (var0.kind != 2) {
            throw new IOException("unknown relocation source kind");
         }

         if (var0.request != 8 || var2[8] == null || var2[8].vectors.length == 0 || var0.slot > 3) {
            throw new IOException("early index source missing");
         }

         long[] var5 = earlyIndexes(var2[8].vectors[0]);
         var3 = var5[var0.slot];
      }

      if ((var0.addend <= 0L || var3 <= Long.MAX_VALUE - var0.addend) && (var0.addend >= 0L || var3 >= Long.MIN_VALUE - var0.addend)) {
         return var3 + var0.addend;
      } else {
         throw new IOException("relocation arithmetic overflow");
      }
   }

   private static long[] earlyIndexes(byte[] var0) throws IOException {
      if (var0.length != 1024) {
         throw new IOException("early vector changed");
      } else {
         long var1 = qword(var0, 13, 14);
         long var3 = qword(var0, 11, 12) - var1 - 24L;
         long var5 = qword(var0, 29, 28) - var1 - 8L;
         if (var3 % 4L == 0L && var5 % 4L == 0L) {
            var3 /= 4L;
            var5 /= 4L;
            if (var3 >= 0L && var5 >= 0L && var3 < 134217728L && var5 < 134217728L) {
               return new long[]{var3, var3 + 40L, var3 + 41L, var5};
            } else {
               throw new IOException("early index outside range");
            }
         } else {
            throw new IOException("early index not word aligned");
         }
      }
   }

   private static long qword(byte[] var0, int var1, int var2) throws IOException {
      if ((var0.length & 3) == 0 && var1 >= 0 && var2 >= 0 && var1 <= var0.length / 4 - 1 && var2 <= var0.length / 4 - 1) {
         long var3 = word(var0, var1);
         long var5 = word(var0, var2);
         return var3 << 32 | var5;
      } else {
         throw new IOException("vector word missing");
      }
   }

   private static long word(byte[] var0, int var1) {
      int var2 = var1 * 4;
      return ((long)var0[var2] & 255L) << 24 | ((long)var0[var2 + 1] & 255L) << 16 | ((long)var0[var2 + 2] & 255L) << 8 | (long)var0[var2 + 3] & 255L;
   }

   private static void verifyShapes(Frame[] var0, Shape[] var1, int var2) throws IOException {
      for(int var3 = 0; var3 < var1.length; ++var3) {
         Shape var4 = var1[var3];
         if (var4.request <= var2) {
            if (var4.request >= var0.length || var0[var4.request] == null) {
               throw new IOException("prior result missing");
            }

            Frame var5 = var0[var4.request];
            if (var5.status != var4.status || var5.instruction != var4.instruction || var5.scalars.length != var4.scalarCount || var5.vectors.length != var4.vectorLengths.length) {
               throw new IOException("prior result shape changed");
            }

            for(int var6 = 0; var6 < var5.vectors.length; ++var6) {
               if (var4.request != 46 && var5.vectors[var6].length != var4.vectorLengths[var6]) {
                  throw new IOException("prior vector shape changed");
               }
            }

            verifyEarlyStatus(var4.request, var5);
            if (var4.request == 46) {
               verifyHenReport(var5);
            }
         }
      }

   }

   static void verifyNewResult(int var0, Frame var1, Shape[] var2, Guards var3) throws Exception {
      Shape var4 = null;

      for(int var5 = 0; var5 < var2.length; ++var5) {
         if (var2[var5].request == var0) {
            var4 = var2[var5];
         }
      }

      if (var4 != null && var1.status == var4.status && var1.instruction == var4.instruction && var1.scalars.length == var4.scalarCount && var1.vectors.length == var4.vectorLengths.length) {
         for(int var6 = 0; var6 < var1.vectors.length; ++var6) {
            if (var0 != 46 && var1.vectors[var6].length != var4.vectorLengths[var6]) {
               throw new IOException("new result vector shape changed");
            }
         }

         verifyEarlyStatus(var0, var1);
         if (var0 == 46) {
            verifyHenReport(var1);
         }

         if (var0 == 12) {
            verifyNativeLayout(var1, var3);
         }

         if (var0 == 16) {
            verifyAliases(var1);
         }

         if (var0 == 27) {
            verifyCodeWindows(var1, var3);
         }

      } else {
         throw new IOException("new result shape changed");
      }
   }

   private static void verifyEarlyStatus(int var0, Frame var1) throws IOException {
      if (var0 == 4) {
         if (var1.vectors.length != 2 || var1.vectors[0].length != 4 || readInt(var1.vectors[0], 0) != 0) {
            throw new IOException("helper setup failed");
         }
      } else if (var0 == 5 || var0 == 6) {
         int var2 = var0 == 5 ? 4 : Integer.MAX_VALUE;
         if (var1.vectors.length != 1 || var1.vectors[0].length != 8 || readInt(var1.vectors[0], 0) != 0 || readInt(var1.vectors[0], 4) != var2) {
            throw new IOException(var0 == 5 ? "helper image setup failed" : "getRGB array-length corruption failed");
         }
      }

   }

   private static void verifyNativeLayout(Frame var0, Guards var1) throws IOException {
      if (var0 != null && var0.scalars.length == 13) {
         long var2 = var0.scalars[0];

         for(int var4 = 0; var4 < 10; ++var4) {
            long var5 = var0.scalars[var4];
            if (var5 < 4294967296L || var5 < 0L || var5 - var2 != var1.nativeDeltas[var4]) {
               throw new IOException("native relative layout changed");
            }
         }

      } else {
         throw new IOException("native symbol results missing");
      }
   }

   private static void verifyAliases(Frame var0) throws IOException {
      if (var0 != null && var0.scalars.length >= 12) {
         long var1 = var0.scalars[1];

         for(int var3 = 3; var3 < 12; var3 += 2) {
            if (var0.scalars[var3] != var1) {
               throw new IOException("shared base aliases diverged");
            }
         }

      } else {
         throw new IOException("shared base result missing");
      }
   }

   private static void verifyCodeWindows(Frame var0, Guards var1) throws Exception {
      if (var0 != null && var0.vectors.length == 3) {
         for(int var2 = 0; var2 < 3; ++var2) {
            if (var0.vectors[var2].length != 16 || !same(hash(var0.vectors[var2]), var1.windowHashes[var2])) {
               throw new IOException("code window signature changed");
            }
         }

      } else {
         throw new IOException("code window results missing");
      }
   }

   private static void verifyHenReport(Frame var0) throws IOException {
      if (var0.vectors.length == 2 && var0.vectors[0].length >= 64 && var0.vectors[0].length <= 4096 && var0.vectors[1].length >= 128 && var0.vectors[1].length <= 131072) {
         byte[] var1 = var0.vectors[0];
         byte[] var2 = var0.vectors[1];
         String[] var3 = new String[]{"HEN14V", "APPLIED=1", "UID=0 uid2=0", "*** ROOT ***"};
         String[] var4 = new String[]{"K 6/6 sites now hold the PATCHED byte", "K sysent[11].sy_narg=2", "K *** 1400.bin APPLIED - syscall 11 IS NOW kexec ***", "G2 sysfilt_ops restore=true", "H4 fetched 562240/562240 B", "H5c launching", "H7 pthread_create rc=0 handle=", "H7 *** hen.bin RUNNING"};

         for(int var5 = 0; var5 < var3.length; ++var5) {
            if (!contains(var1, var3[var5])) {
               throw new IOException("Hx success summary incomplete");
            }
         }

         for(int var7 = 0; var7 < var4.length; ++var7) {
            if (!contains(var2, var4[var7])) {
               throw new IOException("Hx HEN or patch log incomplete");
            }
         }

         if (lineContainsBoth(var2, "K sysent[11].sy_call=", "APPLIED=true") && lineContainsBoth(var2, "L set to ", " ok=true")) {
            String[] var8 = new String[]{"STOP", "no pair", "blind writes", "APPLIED=0"};

            for(int var6 = 0; var6 < var8.length; ++var6) {
               if (contains(var1, var8[var6])) {
                  throw new IOException("Hx reported failed pairing");
               }
            }

            if (contains(var2, "K NOT fully applied") || contains(var2, "safeDown threw")) {
               throw new IOException("Hx reported incomplete kexec patch");
            }
         } else {
            throw new IOException("Hx kernel or ShellCore readback missing");
         }
      } else {
         throw new IOException("Hx report vector bounds changed");
      }
   }

   private static boolean lineContainsBoth(byte[] var0, String var1, String var2) throws IOException {
      byte[] var3 = var1.getBytes("US-ASCII");
      byte[] var4 = var2.getBytes("US-ASCII");

      for(int var5 = 0; var5 <= var0.length - var3.length; ++var5) {
         boolean var6 = true;

         for(int var7 = 0; var7 < var3.length; ++var7) {
            if (var0[var5 + var7] != var3[var7]) {
               var6 = false;
               break;
            }
         }

         if (var6) {
            int var11;
            for(var11 = var5; var11 < var0.length && var0[var11] != 10 && var11 - var5 < 512; ++var11) {
            }

            for(int var8 = var5 + var3.length; var8 <= var11 - var4.length; ++var8) {
               boolean var9 = true;

               for(int var10 = 0; var10 < var4.length; ++var10) {
                  if (var0[var8 + var10] != var4[var10]) {
                     var9 = false;
                     break;
                  }
               }

               if (var9) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private static boolean contains(byte[] var0, String var1) throws IOException {
      byte[] var2 = var1.getBytes("US-ASCII");

      for(int var3 = 0; var3 <= var0.length - var2.length; ++var3) {
         boolean var4 = true;

         for(int var5 = 0; var5 < var2.length; ++var5) {
            if (var0[var3 + var5] != var2[var5]) {
               var4 = false;
               break;
            }
         }

         if (var4) {
            return true;
         }
      }

      return false;
   }

   private static byte[] hash(byte[] var0) throws Exception {
      return MessageDigest.getInstance("SHA-256").digest(var0);
   }

   private static boolean same(byte[] var0, byte[] var1) {
      if (var0.length != var1.length) {
         return false;
      } else {
         int var2 = 0;

         for(int var3 = 0; var3 < var0.length; ++var3) {
            var2 |= var0[var3] ^ var1[var3];
         }

         return var2 == 0;
      }
   }

   static final class Frame {
      final long status;
      final int instruction;
      final long[] scalars;
      final byte[][] vectors;

      Frame(long var1, int var3, long[] var4, byte[][] var5) {
         this.status = var1;
         this.instruction = var3;
         this.scalars = var4;
         this.vectors = var5;
      }
   }

   static final class Rule {
      final int command;
      final int instruction;
      final int offset;
      final int request;
      final int kind;
      final int slot;
      final int high;
      final int low;
      final long addend;

      Rule(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, long var9) {
         this.command = var1;
         this.instruction = var2;
         this.offset = var3;
         this.request = var4;
         this.kind = var5;
         this.slot = var6;
         this.high = var7;
         this.low = var8;
         this.addend = var9;
      }
   }

   static final class Shape {
      final int request;
      final int instruction;
      final int scalarCount;
      final long status;
      final int[] vectorLengths;

      Shape(int var1, long var2, int var4, int var5, int[] var6) {
         this.request = var1;
         this.status = var2;
         this.instruction = var4;
         this.scalarCount = var5;
         this.vectorLengths = var6;
      }
   }

   static final class Guards {
      final long[] nativeDeltas;
      final byte[][] windowHashes;

      Guards(long[] var1, byte[][] var2) {
         this.nativeDeltas = var1;
         this.windowHashes = var2;
      }
   }

   static final class TemplatePin {
      final int command;
      final int length;
      final byte[] sha256;

      TemplatePin(int var1, int var2, byte[] var3) {
         this.command = var1;
         this.length = var2;
         this.sha256 = var3;
      }
   }

   static final class ScheduleEntry {
      final int command;
      final int nextResultRequest;

      ScheduleEntry(int var1, int var2) {
         this.command = var1;
         this.nextResultRequest = var2;
      }
   }

   static final class MarkerPlan {
      final int[] offsets;

      MarkerPlan(int[] var1) {
         this.offsets = var1;
      }
   }

   static final class WriteSite {
      final int command;
      final int instruction;
      final int offset;

      WriteSite(int var1, int var2, int var3) {
         this.command = var1;
         this.instruction = var2;
         this.offset = var3;
      }
   }
}
